 
    
@extends('index')

@section('name')
    {{ isset($name) ? $name : 'page name is here' }}
@endsection

@push('container')
<main class="main">
    <ol class="breadcrumb">
      <li class="breadcrumb-item">Home</li>
      <li class="breadcrumb-item"><a href="#">Admin</a></li>
      <li class="breadcrumb-item active">Dashboard</li>
      <!-- Breadcrumb Menu-->
      <li class="breadcrumb-menu">
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
          <a class="btn btn-secondary" href="#"><i class="icon-speech"></i></a>
          <a class="btn btn-secondary" href="./"><i class="icon-graph"></i> &nbsp;Dashboard</a>
          <a class="btn btn-secondary" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>
        </div>
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header">
            <i class="fa fa-align-justify"></i> عرض الادمن
          </div>
          <div class="card-block">
            <table class="table table-bordered table-striped table-condensed">
              <thead>
                <tr>
                  <th>الرقم</th>
                  <th>اسم المستخدم</th>
                  <th>البريد الاكتروني</th>
                  <th>العنوان</th>
                  <th>تاريخ الميلاد</th>
                  <th>الصلاحيه</th>
                  <th>الصوره</th>
                  <th>الحاله</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>عياش صادق</td>
                  <td>ausihsatk@gmail.com</td>
                  <td>اليمن-اب-المشنه</td>
                  <td>1/2/2001</td>
                  <td>ادمن</td>
                  <td>
                    <img src="img/avatars/6.jpg" class="img-avatar" alt="admin@bootstrapmaster.com" width="35px" height="35px">
                  </td>
                  <td>
                    <button type="button" class="tag tag-warning" style="margin-bottom: 4px">
                      <span>نشط</span>
                    </button>
                  </td>
                  <td>
                    <button type="button" class="tag tag-success icon-note" style="margin-bottom: 4px">
                      <span>تعديل</span>
                    </button>
                    <button type="button" class="tag tag-danger icon-trash" style="margin-bottom: 4px">
                      <span>حذف</span>
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
            <nav>
              <ul class="pagination">
                <li class="page-item">
                  <a class="page-link" href="#">Prev</a>
                </li>
                <li class="page-item active">
                  <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item"><a class="page-link" href="#">4</a></li>
                <li class="page-item">
                  <a class="page-link" href="#">Next</a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
      <!--/col-->
    </div>

    <!--/.container-fluid-->
  </main>
@endpush

 
    
