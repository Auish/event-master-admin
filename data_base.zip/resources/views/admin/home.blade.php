@extends('index')

@section('name')
    {{ isset($name) ? $name : 'page name is here' }}
@endsection

@push('container')
<main class="main">
    <ol class="breadcrumb">
      <li class="breadcrumb-item"> </li>
      <li class="breadcrumb-item"><a href="#">الادمن</a></li>
      <li class="breadcrumb-item active">الرئسيه</li>
      <!-- Breadcrumb Menu-->
      <li class="breadcrumb-menu">
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
          <a class="btn btn-secondary" href="#"><i class="icon-speech"></i></a>
          <a class="btn btn-secondary" href="./"><i class="icon-graph"></i> &nbsp;Dashboard</a>
          <a class="btn btn-secondary" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>
        </div>
      </li>
    </ol>
    <div class="card-group m-b-1">
      <div class="card">
        <div class="card-block">
          <div class="h1 text-muted text-xs-right m-b-2">
            <i class="icon-people"></i>
          </div>
          <div class="h4 m-b-0">87.500</div>
          <small class="text-muted text-uppercase font-weight-bold">Visitors</small>
          <progress class="progress progress-xs progress-info m-t-1 m-b-0" value="25" max="100">
            25%
          </progress>
        </div>
      </div>
      <div class="card">
        <div class="card-block">
          <div class="h1 text-muted text-xs-right m-b-2">
            <i class="icon-user-follow"></i>
          </div>
          <div class="h4 m-b-0">385</div>
          <small class="text-muted text-uppercase font-weight-bold">New Clients</small>
          <progress class="progress progress-xs progress-success m-t-1 m-b-0" value="25" max="100">
            25%
          </progress>
        </div>
      </div>
      <div class="card">
        <div class="card-block">
          <div class="h1 text-muted text-xs-right m-b-2">
            <i class="icon-basket-loaded"></i>
          </div>
          <div class="h4 m-b-0">1238</div>
          <small class="text-muted text-uppercase font-weight-bold">Products sold</small>
          <progress class="progress progress-xs progress-warning m-t-1 m-b-0" value="25" max="100">
            25%
          </progress>
        </div>
      </div>
      <div class="card">
        <div class="card-block">
          <div class="h1 text-muted text-xs-right m-b-2">
            <i class="icon-pie-chart"></i>
          </div>
          <div class="h4 m-b-0">28%</div>
          <small class="text-muted text-uppercase font-weight-bold">Returning Visitors</small>
          <progress class="progress progress-xs progress-primary m-t-1 m-b-0" value="25" max="100">
            25%
          </progress>
        </div>
      </div>
      <div class="card">
        <div class="card-block">
          <div class="h1 text-muted text-xs-right m-b-2">
            <i class="icon-speedometer"></i>
          </div>
          <div class="h4 m-b-0">5:34:11</div>
          <small class="text-muted text-uppercase font-weight-bold">Avg. Time</small>
          <progress class="progress progress-xs progress-danger m-t-1 m-b-0" value="25" max="100">
            25%
          </progress>
        </div>
      </div>
    </div>
    <div class="card">
      <div class="card-header">
        <i class="fa fa-align-justify"></i> Combined All Table
      </div>
      <div class="card-block">
        <table class="table table-bordered table-striped table-condensed">
          <thead>
            <tr>
              <th>Username</th>
              <th>Date registered</th>
              <th>Role</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>Vishnu Serghei</td>
              <td>2012/01/01</td>
              <td>Member</td>
              <td>
                <span class="tag tag-success">Active</span>
              </td>
            </tr>
            <tr>
              <td>Zbyněk Phoibos</td>
              <td>2012/02/01</td>
              <td>Staff</td>
              <td>
                <span class="tag tag-danger">Banned</span>
              </td>
            </tr>
            <tr>
              <td>Einar Randall</td>
              <td>2012/02/01</td>
              <td>Admin</td>
              <td>
                <span class="tag tag-default">Inactive</span>
              </td>
            </tr>
            <tr>
              <td>Félix Troels</td>
              <td>2012/03/01</td>
              <td>Member</td>
              <td>
                <span class="tag tag-warning">Pending</span>
              </td>
            </tr>
            <tr>
              <td>Aulus Agmundr</td>
              <td>2012/01/21</td>
              <td>Staff</td>
              <td>
                <span class="tag tag-success">Active</span>
              </td>
            </tr>
          </tbody>
        </table>
        <nav>
          <ul class="pagination">
            <li class="page-item"><a class="page-link" href="#">Prev</a></li>
            <li class="page-item active">
              <a class="page-link" href="#">1</a>
            </li>
            <li class="page-item"><a class="page-link" href="#">2</a></li>
            <li class="page-item"><a class="page-link" href="#">3</a></li>
            <li class="page-item"><a class="page-link" href="#">4</a></li>
            <li class="page-item"><a class="page-link" href="#">Next</a></li>
          </ul>
        </nav>
      </div>
    </div>
    <!--/.container-fluid-->
  </main>
@endpush

 
    
