 
    
@extends('index')

@section('name')
    {{ isset($name) ? $name : 'page name is here' }}
@endsection

@push('container')
<main class="main">
    <ol class="breadcrumb">
      <li class="breadcrumb-item">Home</li>
      <li class="breadcrumb-item"><a href="#">Admin</a></li>
        <li class="breadcrumb-item active">Dashboard</li>
        <!-- Breadcrumb Menu-->
        <li class="breadcrumb-menu">
            <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                <a class="btn btn-secondary" href="#"><i class="icon-speech"></i></a>
                <a class="btn btn-secondary" href="./"><i class="icon-graph"></i> &nbsp;Dashboard</a>
          <a class="btn btn-secondary" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>
        </div>
      </li>
    </ol>
    <div class="animated fadeIn">
    
  <div class="row">
      <div class="col-lg-12">
          <div class="card">
              <div class="card-header">
                  <i class="fa fa-align-justify"></i> اسم النموذج
              </div>
              <div class="card-block">
                <!-- Search and filter section -->
                <div class="row mb-2">
                    <div class="col-md-6">
                        <input type="text" class="form-control" id="tableSearch" placeholder="Search...">
                    </div>
                    <div class="col-md-6">
                        <select class="form-control" id="roleFilter">
                            <option value="">Filter by Role</option>
                            <option value="Member">Member</option>
                            <option value="Staff">Staff</option>
                            <option value="Admin">Admin</option>
                        </select>
                    </div>
                </div>
                <table class="table table-bordered table-striped table-condensed" id="dataTable">
                    <thead>
                        <tr>
                            <th>الرقم</th>
                            <th>اسم المنتج  </th>
                            <th>السعر</th>
                            <th>الوصف</th>
                            <th>صوره</th>
                            <th>الحاله</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>ملبوس الزفاف</td>
                            <td>10000</td>
                            <td>ملبوس الزفاف اناقه وراحه خلي عرسك يكتمل سعاده مع ملبوس التراث</td>
                            <td>
                              <img src="http://127.0.0.1:8000/backt/images (4).jfif" class="img-avatar" alt="admin@bootstrapmaster.com" width="35px" height="35px">
                          </td>
                          
                            <td>
                                <span class="tag tag-success">نشط</span>
                            </td>
                            <td>
                              <button type="button" class="tag tag-success icon-note" style="margin-bottom: 4px">
                                <span>تعديل</span>
                              </button>
                              <button type="button" class="tag tag-danger icon-trash" style="margin-bottom: 4px">
                                <span>حذف</span>
                              </button>
                            </td>
               </tr>
            
               </tbody>
               </table>
               <div id="selectedRowData" class="mt-3"></div>
               <nav>
                   <ul class="pagination">
                       <li class="page-item"><a class="page-link" href="#">Prev</a>
                       </li>
                       <li class="page-item active">
                           <a class="page-link" href="#">1</a>
                       </li>
                       <li class="page-item"><a class="page-link" href="#">2</a>
                       </li>
                       <li class="page-item"><a class="page-link" href="#">3</a>
                       </li>
                       <li class="page-item"><a class="page-link" href="#">4</a>
                       </li>
                       <li class="page-item"><a class="page-link" href="#">Next</a>
                       </li>
                   </ul>
               </nav>
           </div>
</div>
</div>
</div>

<!--/col-->
</div>
<!--/row-->

<!--/row-->

<!--/row-->


<!--/.container-fluid-->
</main> 
@endpush

 
    
