 
    


<?php $__env->startSection('name'); ?>
    <?php echo e(isset($name) ? $name : 'page name is here'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('container'); ?>
<main class="main">
    <ol class="breadcrumb">
        <li class="breadcrumb-item">الرئسيه</li>
        <li class="breadcrumb-item"><a href="#">الخدمات </a></li>
        <li class="breadcrumb-item active">عرض</li>
      <!-- Breadcrumb Menu-->
      <li class="breadcrumb-menu">
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
          <a class="btn btn-secondary" href="#"><i class="icon-speech"></i></a>
          <a class="btn btn-secondary" href="./"><i class="icon-graph"></i> &nbsp;Dashboard</a>
          <a class="btn btn-secondary" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>
        </div>
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header">
            <i class="fa fa-align-justify"></i> عرض الادمن
          </div>
          <div class="card-block">
            <table class="table table-bordered table-striped table-condensed">
              <thead>
                <tr>
                  <th>الرقم</th>
                  <th>اسم الخدمه الفرعيه</th> 
                  <th>الحاله</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td> مخيمات الاعراس</td>   
                  <td>
                    <button type="button" class="tag tag-warning" style="margin-bottom: 4px">
                      <span>نشط</span>
                    </button>
                  </td>
                  <td>
                    <button type="button" class="tag tag-success icon-note" style="margin-bottom: 4px">
                      <span>تعديل</span>
                    </button>
                    <button type="button" class="tag tag-danger icon-trash" style="margin-bottom: 4px">
                      <span>حذف</span>
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
            <nav>
              <ul class="pagination">
                <li class="page-item">
                  <a class="page-link" href="#">Prev</a>
                </li>
                <li class="page-item active">
                  <a class="page-link" href="#">1</a>
                </li>
                <li class="page-item"><a class="page-link" href="#">2</a></li>
                <li class="page-item"><a class="page-link" href="#">3</a></li>
                <li class="page-item"><a class="page-link" href="#">4</a></li>
                <li class="page-item">
                  <a class="page-link" href="#">Next</a>
                </li>
              </ul>
            </nav>
          </div>
        </div>
      </div>
      <!--/col-->
    </div>

    <!--/.container-fluid-->
  </main>
<?php $__env->stopPush(); ?>

 
    

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desktop\data_base\resources\views/admin/Sub-service/index.blade.php ENDPATH**/ ?>