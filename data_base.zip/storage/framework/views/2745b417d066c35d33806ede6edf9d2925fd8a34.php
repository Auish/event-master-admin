

<?php $__env->startSection('name'); ?>
    <?php echo e(isset($name) ? $name : 'page name is here'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('container'); ?>
<main class="main">
    <ol class="breadcrumb">
      <li class="breadcrumb-item">الرئسيه</li>
      <li class="breadcrumb-item"><a href="#">الخدمات الفرعيه</a></li>
        <li class="breadcrumb-item active">اضافه</li>
        <!-- Breadcrumb Menu-->
        <li class="breadcrumb-menu">
            <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                <a class="btn btn-secondary" href="#"><i class="icon-speech"></i></a>
                <a class="btn btn-secondary" href="./"><i class="icon-graph"></i> &nbsp;Dashboard</a>
          <a class="btn btn-secondary" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>
        </div>
      </li>
    </ol>
     
  <!--/row-->
  <div class="card">
     <div class="card-header">
       <strong>الادمن</strong>
     </div>
     <div class="form">
        <form class="form-horizontal" id="subCategory" method="post" action="" enctype="multipart/form-data">
          <div class="form-group">
            <label for="SubCategoryName" class="control-label col-lg-2">اسم الفئه الفرعيه</label>
            <div class="col-lg-7">
              <input class="form-control" id="subcategory_name" name="subcategory_name" type="text">
            </div>
          </div>
          <div class="form-group">
            <label for="CategoryName" class="control-label col-lg-2">من الفئه الرئسيه</label>
            <div class="col-lg-7">
              <select name="category_id" id="category_id" class="form-control">
                <option>Select a Category</option>

                <option value="">SDFDFFD</option>
                
              </select>
            </div>
          </div>


<div class="form-group">
    <label for="SubCategoryStatus" class="control-label col-lg-2">
           حاله الفئه الفرعيه
            </label>
    <div class="col-lg-7">
        <select name="subcategory_status" class="form-control m-bot15">
                <option>نشط</option>
                <option>غير نشط</option>
              </select>
    </div>
</div>
<div class="form-actions">
  <button type="submit" class="btn btn-primary">حفظ</button>
  <button type="button" class="btn btn-danger">الغاء</button>
</div>
</form>
</div>
</div>
<!--/row-->

<!--/row-->


<!--/.container-fluid-->
</main>
<?php $__env->stopPush(); ?>

 
    

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desktop\data_base\resources\views/admin/Sub-service/create.blade.php ENDPATH**/ ?>