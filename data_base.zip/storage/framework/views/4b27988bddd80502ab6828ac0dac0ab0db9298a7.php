 
    


<?php $__env->startSection('name'); ?>
    <?php echo e(isset($name) ? $name : 'page name is here'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('container'); ?>
<main class="main">
    <ol class="breadcrumb">
      <li class="breadcrumb-item">Home</li>
      <li class="breadcrumb-item"><a href="#">Admin</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
          <!-- Breadcrumb Menu-->
          <li class="breadcrumb-menu">
              <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                  <a class="btn btn-secondary" href="#"><i class="icon-speech"></i></a>
                  <a class="btn btn-secondary" href="./"><i class="icon-graph"></i> &nbsp;Dashboard</a>
          <a class="btn btn-secondary" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>
        </div>
      </li>
    </ol>
    <div class="animated fadeIn">
      <div class="row">
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header">
              <i class="fa fa-align-justify"></i>بيانات النموذج
            </div>
            <form action="" method="post" enctype="multipart/form-data">
              <div class="card-block">
                <div class="form-group">
                  <label for="ProductName" class="col-lg-2 col-sm-2 control-label">
                    اسم النموذج
                  </label>
                  <div class="col-lg-7">
                    <input type="text" name="product_name" class="form-control" id="product_name" required="">
                  </div>
                </div>
                <div class="form-group">
                  <label for="ProductName" class="col-lg-2 col-sm-2 control-label">
                    وصف النموذج
                  </label>
                  <div class="col-lg-7">
                    <input type="text" name="product_name" class="form-control" id="product_name" required="">
                  </div>
                </div>

                <div class="form-group">
                  <label for="ProductQuantity" class="col-lg-2 col-sm-2 control-label">
                    عدد الخدمات في النوذج</label>
                  <div class="col-lg-7">
                    <input type="number" name="product_quantity" class="form-control" id="product_quantity" required="">
                  </div>
                </div>
                <div class="form-group">
                  <label for="ProductPrice" class="col-lg-2 col-sm-2 control-label">
                    سعر النموذج
                  </label>
                  <div class="col-lg-7">
                    <input type="number" step="any" name="product_price" class="form-control" id="product_price" required="">
                  </div>
                </div>
                <div class="form-group">
                  <label for="ProductPrice" class="col-lg-2 col-sm-2 control-label">
                    نسبه الخصم لكل منتج
                  </label>
                  <div class="col-lg-7">
                    <input type="number" step="any" name="product_price" class="form-control" id="product_price" required="">
                  </div>
                </div>
                <div class="form-group">
                  <label for="ProductStatus" class="control-label col-lg-2">
                    حاله النموذج
                  </label>
                  <div class="col-lg-7">
                    <select name="product_status" class="form-control" required="">
                      <option>Out of Stock</option>
                      <option>In Stock</option>
                    </select>
                  </div>
                </div>
                <!--/row-->

                <div class="form-group">
                  <label class="control-label col-md-2">
                    (الرئسية) اضافه صوره
                  </label>
                  <div class="controls col-md-9">
                    <div class="fileupload fileupload-new" data-provides="fileupload">
                      <span class="btn btn-default btn-file">
                        <input type="file" name="product_master_image" class="default" onchange="readURL(this);" set-to="div7" required="">
                      </span>
                      <span class="fileupload-preview" style="margin-left: 5px"></span>
                      <a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none; margin-left: 5px"></a>
              </div>
  </div>
  </div>
  <div class="form-group">
      <label class="control-label col-md-2" style="margin-left: 10px">
                    صوره المنتج(الرئسية)
                  </label>
      <div class="col-md-9">
          <div class="fileupload fileupload-new" data-provides="fileupload">
              <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                  <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div7">
              </div>
          </div>
      </div>
  </div>



  </div>
  <!--=*= PRODUCT ADDITIONAL IMAGE =*=-->
  <div class="form-actions">
      <button type="submit" class="btn btn-primary">حفظ</button>
      <button type="button" class="btn btn-danger">الغاء</button>
  </div>
  </form></div>

  
  </div>

  <!--/col-->

  <div class="col-lg-6 maineu">
      <div class="card">
          <div class="card-header">
              <i class="fa fa-align-justify"></i> صور المنتج(الفرعيه)
          </div>
          <form action="" method="post" enctype="multipart/form-data">
              <div class="card-block">
                  <!--/row-->

                  <!--=*= PRODUCT ADDITIONAL IMAGE =*=-->
                  <div class="d-flex d-inline">
                      <div class="form-group">
                          <div class="col-md-3">
                              <div class="fileupload fileupload-new" data-provides="fileupload">
                                  <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                      <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div8">
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-3">
                              <div class="fileupload fileupload-new" data-provides="fileupload">
                                  <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                      <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div9">
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-3">
                              <div class="fileupload fileupload-new" data-provides="fileupload">
                                  <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                      <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div10">
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                              <div class="fileupload fileupload-new" data-provides="fileupload">
                                  <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                      <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div8">
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-3">
                              <div class="fileupload fileupload-new" data-provides="fileupload">
                                  <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                      <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div9">
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-3">
                              <div class="fileupload fileupload-new" data-provides="fileupload">
                                  <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                      <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div10">
                                  </div>
                              </div>
                          </div>
                      </div>
                      <div class="form-group">
                          <div class="col-md-3">
                              <div class="fileupload fileupload-new" data-provides="fileupload">
                                  <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                      <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div8">
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-3">
                              <div class="fileupload fileupload-new" data-provides="fileupload">
                                  <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                      <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div9">
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-3">
                              <div class="fileupload fileupload-new" data-provides="fileupload">
                                  <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                      <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div10">
                                  </div>
                              </div>
                          </div>
                      </div>
                  </div>

                  <button type="button" class="btn btn-outline-success" onclick="addClassOpen()">
                  <i class="fa fa-magic"></i>&nbsp; اضافه المزيد
                </button>
              </div>


          </form>
      </div>
  </div>
  </div>
  <div class="row">
      <div class="col-lg-12">
          <div class="card">
              <div class="card-header">
                  <i class="fa fa-align-justify"></i> Combined All Table
              </div>
              <div class="card-block">
                <!-- Search and filter section -->
                <div class="row mb-2">
                    <div class="col-md-6">
                        <input type="text" class="form-control" id="tableSearch" placeholder="Search...">
                    </div>
                    <div class="col-md-6">
                        <select class="form-control" id="roleFilter">
                            <option value="">Filter by Role</option>
                            <option value="Member">Member</option>
                            <option value="Staff">Staff</option>
                            <option value="Admin">Admin</option>
                        </select>
                    </div>
                </div>
                <table class="table table-bordered table-striped table-condensed" id="dataTable">
                    <thead>
                        <tr>
                            <th><input type="checkbox" id="selectAll"></th>
                            <th>الرقم</th>
                            <th>اسم المنتج  </th>
                            <th>السعر</th>
                            <th>الوصف</th>
                            <th>صوره</th>
                            <th>الحاله</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th><input type="checkbox" id="selectAll"></th>
                            <td>1</td>
                            <td>ملبوس الزفاف</td>
                            <td>10000</td>
                            <td>ملبوس الزفاف اناقه وراحه خلي عرسك يكتمل سعاده مع ملبوس التراث</td>
                            <td>
                              <img src="http://127.0.0.1:8000/backt/images (4).jfif" class="img-avatar" alt="admin@bootstrapmaster.com" width="35px" height="35px">
                          </td>
                          
                            <td>
                                <span class="tag tag-success">نشط</span>
                            </td>
                            <td>
                              <button type="button" class="tag tag-success icon-note" style="margin-bottom: 4px">
                                <span>تعديل</span>
                              </button>
                              <button type="button" class="tag tag-danger icon-trash" style="margin-bottom: 4px">
                                <span>حذف</span>
                              </button>
                            </td>
               </tr>
            
               </tbody>
               </table>
               <div id="selectedRowData" class="mt-3"></div>
               <nav>
                   <ul class="pagination">
                       <li class="page-item"><a class="page-link" href="#">Prev</a>
                       </li>
                       <li class="page-item active">
                           <a class="page-link" href="#">1</a>
                       </li>
                       <li class="page-item"><a class="page-link" href="#">2</a>
                       </li>
                       <li class="page-item"><a class="page-link" href="#">3</a>
                       </li>
                       <li class="page-item"><a class="page-link" href="#">4</a>
                       </li>
                       <li class="page-item"><a class="page-link" href="#">Next</a>
                       </li>
                   </ul>
               </nav>
           </div>
          </div>
      </div>
  </div>
  <div class="row">
      <div class="col-lg-12">
          <div class="card">
              <div class="card-header">
                  <i class="fa fa-edit"></i>Form Elements
                  <div class="card-actions">
                      <a href="#" class="btn-setting"><i class="icon-settings"></i></a>
                      <a href="#" class="btn-minimize"><i class="icon-arrow-up"></i></a>
                      <a href="#" class="btn-close"><i class="icon-close"></i></a>
                  </div>
              </div>
              <div class="card-block">
                  <form action="" method="post" enctype="multipart/form-data">
                      <div class="card-block">
                          <div class="form-group">
                              <label for="ProductStatus" class="control-label col-lg-2">الفئة</label>
                              <div class="col-lg-7">
                                  <input type="text" name="product_name" class="form-control" id="product_name" required="" readonly="">
                              </div>
                          </div>
                          <div class="form-group">
                              <label for="ProductStatus" class="control-label col-lg-2">الفئه الفرعيه</label>
                              <div class="col-lg-7">
                                  <input type="text" name="product_name" class="form-control" id="product_name" required="" readonly="">
                              </div>
                          </div>
                          <div class="form-group">
                              <label for="ProductName" class="col-lg-2 col-sm-2 control-label">اسم المنتج</label>
                              <div class="col-lg-7">
                                  <input type="text" name="product_name" class="form-control" id="product_name" required="" readonly="">
                              </div>
                          </div>
                          <div class="form-group">
                              <label for="ProductName" class="col-lg-2 col-sm-2 control-label">وصف المنتج</label>
                              <div class="col-lg-7">
                                  <input type="text" name="product_name" class="form-control" id="product_name" required="" readonly="">
                              </div>
                          </div>
                          <div class="form-group">
                              <label for="ProductQuantity" class="col-lg-2 col-sm-2 control-label">Product Quantity</label>
                              <div class="col-lg-7">
                                  <input type="number" name="product_quantity" class="form-control" id="product_quantity" required="" readonly="">
                              </div>
                          </div>
                          <div class="form-group">
                              <label for="ProductPrice" class="col-lg-2 col-sm-2 control-label">سعر المنتج</label>
                              <div class="col-lg-7">
                                  <input type="number" step="any" name="product_price" class="form-control" id="product_price" required="" readonly="">
                              </div>
                          </div>
                          <div class="form-group">
                              <label for="ProductStatus" class="control-label col-lg-2">حاله المنتج</label>
                              <div class="col-lg-7">
                                  <input type="text" name="product_name" class="form-control" id="product_name" required="" readonly="">
                              </div>
                          </div>
                          <!--/row-->
                          <div class="form-group">
                              <label class="control-label col-md-2">صوره المنتج(الرئسية)</label>
                              <div class="col-md-9">
                                  <div class="fileupload fileupload-new" data-provides="fileupload">
                                      <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                          <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div7">
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <!--=*= PRODUCT ADDITIONAL IMAGE =*=-->
                          <div class="d-flex d-inline">
                              <div class="form-group">
                                  <label class="control-label col-md-2">صور المنتج(الفرعيه)</label>
                                  <div class="col-md-3">
                                      <div class="fileupload fileupload-new" data-provides="fileupload">
                                          <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                              <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div8">
                                          </div>
                                      </div>
                                  </div>
                                  <div class="col-md-3">
                                      <div class="fileupload fileupload-new" data-provides="fileupload">
                                          <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                              <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div9">
                                          </div>
                                      </div>
                                  </div>
                                  <div class="col-md-3">
                                      <div class="fileupload fileupload-new" data-provides="fileupload">
                                          <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                                              <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div10">
                                          </div>
                                      </div>
                                  </div>
                              </div>
                          </div>
                          <div class="d-flex d-inline mast"></div>
                          <button type="button" class="btn btn-outline-success" onclick="addClassOpen()">
                              <i class="fa fa-magic"></i>&nbsp; اضافه المزيد
                          </button>
                      </div>
                      <div class="form-actions">
                          <button type="submit" class="btn btn-primary">حفظ</button>
                          <button type="button" class="btn btn-danger">الغاء</button>
                      </div>
                  </form>

              </div>
          </div>
      </div>
      <!--/col-->
  </div>
  <!--/col-->
  </div>
  <!--/row-->

  <!--/row-->

  <!--/row-->
  

  <!--/.container-fluid-->
  </main>
<?php $__env->stopPush(); ?>

 
    
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desktop\data_base\resources\views/admin/models/craet-db.blade.php ENDPATH**/ ?>