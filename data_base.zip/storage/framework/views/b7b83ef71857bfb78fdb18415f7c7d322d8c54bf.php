 
    


<?php $__env->startSection('name'); ?>
    <?php echo e(isset($name) ? $name : 'page name is here'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('container'); ?>
<main class="main">
    <ol class="breadcrumb">
      <li class="breadcrumb-item">الرئسيه</li>
      <li class="breadcrumb-item"><a href="#">النماذج</a></li>
      <li class="breadcrumb-item active">اضافه</li>
      <!-- Breadcrumb Menu-->
      <li class="breadcrumb-menu">
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
          <a class="btn btn-secondary" href="#"><i class="icon-speech"></i></a>
          <a class="btn btn-secondary" href="./"><i class="icon-graph"></i> &nbsp;Dashboard</a>
          <a class="btn btn-secondary" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>
        </div>
      </li>
    </ol>
    <div class="animated fadeIn">
      <div class="row">
        <div class="col-lg-6">
          <div class="card">
            <div class="card-header">
              <i class="fa fa-align-justify"></i>بيانات النموذج
            </div>
            <form action="" method="post" enctype="multipart/form-data">
              <div class="card-block">
                <div class="form-group">
                  <label for="ProductName" class="col-lg-2 col-sm-2 control-label">
                    اسم النموذج
                  </label>
                  <div class="col-lg-7">
                    <input type="text" name="product_name" class="form-control" id="product_name" required="">
                  </div>
                </div>
                <div class="form-group">
                  <label for="ProductName" class="col-lg-2 col-sm-2 control-label">
                    وصف النموذج
                  </label>
                  <div class="col-lg-7">
                    <input type="text" name="product_name" class="form-control" id="product_name" required="">
                  </div>
                </div>

                <div class="form-group">
                  <label for="ProductQuantity" class="col-lg-2 col-sm-2 control-label">
                    عدد الخدمات في النوذج</label>
                  <div class="col-lg-7">
                    <input type="number" name="product_quantity" class="form-control" id="product_quantity" required="">
                  </div>
                </div>
                <div class="form-group">
                  <label for="ProductPrice" class="col-lg-2 col-sm-2 control-label">
                    سعر النموذج
                  </label>
                  <div class="col-lg-7">
                    <input type="number" step="any" name="product_price" class="form-control" id="product_price" required="">
                  </div>
                </div>
                <div class="form-group">
                  <label for="ProductPrice" class="col-lg-2 col-sm-2 control-label">
                    نسبه الخصم لكل منتج
                  </label>
                  <div class="col-lg-7">
                    <input type="number" step="any" name="product_price" class="form-control" id="product_price" required="">
                  </div>
                </div>
                <div class="form-group">
                  <label for="ProductStatus" class="control-label col-lg-2">
                    حاله النموذج
                  </label>
                  <div class="col-lg-7">
                    <select name="product_status" class="form-control" required="">
                      <option>Out of Stock</option>
                      <option>In Stock</option>
                    </select>
                  </div>
                </div>
                <!--/row-->

                <div class="form-group">
                  <label class="control-label col-md-2">
                    (الرئسية) اضافه صوره
                  </label>
                  <div class="controls col-md-9">
                    <div class="fileupload fileupload-new" data-provides="fileupload">
                      <span class="btn btn-default btn-file">
                        <input type="file" name="product_master_image" class="default" onchange="readURL(this);" set-to="div7" required="">
                      </span>
                      <span class="fileupload-preview" style="margin-left: 5px"></span>
                      <a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none; margin-left: 5px"></a>
                    </div>
                  </div>
                </div>
                <div class="form-group">
                  <label class="control-label col-md-2" style="margin-left: 10px">
                    صوره المنتج(الرئسية)
                  </label>
                  <div class="col-md-9">
                    <div class="fileupload fileupload-new" data-provides="fileupload">
                      <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                        <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div7">
                      </div>
                    </div>
                  </div>
                </div>
                <div class="card-header">
                  <i class="fa fa-align-justify"></i>بيانات المنتج
                </div>
                <div class="card-block">
                  <div class="form-group">
                    <label for="ProductStatus" class="control-label col-lg-2">الفئة</label>
                    <div class="col-lg-7">
                      <select name="category_id" id="category_id" class="form-control" required="">
                        <option value="">Select a Category</option>

                        <option value=" "></option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="ProductStatus" class="control-label col-lg-2">
                      الفئه الفرعيه
                    </label>
                    <div class="col-lg-7">
                      <select name="subcategory_id" id="subcategory_id" class="form-control" required="">
                        <option value="">Select a Subcategory</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="ProductName" class="col-lg-2 col-sm-2 control-label">
                      اسم المنتج
                    </label>
                    <div class="col-lg-7">
                      <input type="text" name="product_name" class="form-control" id="product_name" required="">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="ProductName" class="col-lg-2 col-sm-2 control-label">
                      وصف المنتج
                    </label>
                    <div class="col-lg-7">
                      <input type="text" name="product_name" class="form-control" id="product_name" required="">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="ProductQuantity" class="col-lg-2 col-sm-2 control-label">Product Quantity</label>
                    <div class="col-lg-7">
                      <input type="number" name="product_quantity" class="form-control" id="product_quantity" required="">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="ProductPrice" class="col-lg-2 col-sm-2 control-label">
                      سعر المنتج
                    </label>
                    <div class="col-lg-7">
                      <input type="number" step="any" name="product_price" class="form-control" id="product_price" required="">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="ProductStatus" class="control-label col-lg-2">
                      حاله المنتج
                    </label>
                    <div class="col-lg-7">
                      <select name="product_status" class="form-control" required="">
                        <option>Out of Stock</option>
                        <option>In Stock</option>
                      </select>
                    </div>
                  </div>
                  <!--/row-->

                  <div class="form-group">
                    <label class="control-label col-md-2"> اضافه صوره </label>
                    <div class="controls col-md-9">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <span class="btn btn-default btn-file">
                          <input type="file" name="product_master_image" class="default" onchange="readURL(this);" set-to="div7" required="">
                        </span>
                        <span class="fileupload-preview" style="margin-left: 5px"></span>
                        <a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none; margin-left: 5px"></a>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-2">
                      صوره المنتج(الرئسية)
                    </label>
                    <div class="col-md-9">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                          <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div7">
                        </div>
                      </div>
                    </div>
                  </div>

                  <!--=*= PRODUCT ADDITIONAL IMAGE =*=-->
                  <div class="d-flex d-inline">
                    <div class="form-group">
                      <label class="control-label col-md-2">
                        اضافه صور فرعيه
                      </label>
                      <div class="controls col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <span class="btn btn-default btn-file">
                            <input type="file" name="products_image_one" class="default" onchange="readURL(this);" set-to="div8">
                          </span>
                          <span class="fileupload-preview" style="margin-left: 5px"></span>
                          <a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none; margin-left: 5px"></a>
                        </div>
                      </div>
                      <div class="controls col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <span class="btn btn-default btn-file">
                            <input type="file" name="products_image_two" class="default" onchange="readURL(this);" set-to="div9">
                          </span>
                          <span class="fileupload-preview" style="margin-left: 5px"></span>
                          <a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none; margin-left: 5px"></a>
                        </div>
                      </div>
                      <div class="controls col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <span class="btn btn-default btn-file">
                            <input type="file" name="products_image_three" class="default" onchange="readURL(this);" set-to="div10">
                          </span>
                          <span class="fileupload-preview" style="margin-left: 5px"></span>
                          <a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none; margin-left: 5px"></a>
                        </div>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-md-2">
                        صور المنتج(الفرعيه)
                      </label>
                      <div class="col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                            <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div8">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                            <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div9">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                            <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div10">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="d-flex d-inline mast">
                    <div class="form-group mast">
                      <label class="control-label col-md-2">
                        اضافه صور فرعيه
                      </label>
                      <div class="controls col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <span class="btn btn-default btn-file">
                            <input type="file" name="products_image_one" class="default" onchange="readURL(this);" set-to="div8">
                          </span>
                          <span class="fileupload-preview" style="margin-left: 5px"></span>
                          <a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none; margin-left: 5px"></a>
                        </div>
                      </div>
                      <div class="controls col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <span class="btn btn-default btn-file">
                            <input type="file" name="products_image_two" class="default" onchange="readURL(this);" set-to="div9">
                          </span>
                          <span class="fileupload-preview" style="margin-left: 5px"></span>
                          <a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none; margin-left: 5px"></a>
                        </div>
                      </div>
                      <div class="controls col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <span class="btn btn-default btn-file">
                            <input type="file" name="products_image_three" class="default" onchange="readURL(this);" set-to="div10">
                          </span>
                          <span class="fileupload-preview" style="margin-left: 5px"></span>
                          <a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none; margin-left: 5px"></a>
                        </div>
                      </div>
                    </div>
                    <div class="form-group mast">
                      <label class="control-label col-md-2">
                        صور المنتج(الفرعيه)
                      </label>
                      <div class="col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                            <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div8">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                            <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div9">
                          </div>
                        </div>
                      </div>
                      <div class="col-md-3">
                        <div class="fileupload fileupload-new" data-provides="fileupload">
                          <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                            <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div10">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <button type="button" class="btn btn-outline-success" onclick="addClassOpen()">
                    <i class="fa fa-magic"></i>&nbsp; اضافه المزيد
                  </button>
                </div>
                <!--=*= PRODUCT ADDITIONAL IMAGE =*=-->
              </div>
            </form>
          </div>
        </div>
        <!--/col-->

        <div class="col-lg-6 maineu">
          <div class="card">
            <div class="card-header">
              <i class="fa fa-align-justify"></i> صور المنتج(الفرعيه)
            </div>
            <form action="" method="post" enctype="multipart/form-data">
              <div class="card-block">
                <!--/row-->

                <!--=*= PRODUCT ADDITIONAL IMAGE =*=-->
                <div class="d-flex d-inline">
                  <div class="form-group">
                    <div class="col-md-3">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                          <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div8">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                          <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div9">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                          <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div10">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-3">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                          <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div8">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                          <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div9">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                          <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div10">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-md-3">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                          <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div8">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                          <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div9">
                        </div>
                      </div>
                    </div>
                    <div class="col-md-3">
                      <div class="fileupload fileupload-new" data-provides="fileupload">
                        <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
                          <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div10">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

               
                  <a href="<?php echo e(route('admin.models.create-data')); ?>">
                    <i class="fa fa-magic"></i>&nbsp; اضافه من قاعده
                    البيانات</a>
              
              </div>

              <div class="form-actions">
                <button type="submit" class="btn btn-primary">حفظ</button>
                <button type="button" class="btn btn-danger">الغاء</button>
              </div>
            </form>
          </div>
        </div>
        <!--/col-->
      </div>
      <!--/row-->

      <!--/row-->

      <!--/row-->
    </div>

    <!--/.container-fluid-->
  </main>
<?php $__env->stopPush(); ?>

 
    

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desktop\data_base\resources\views/admin/models/create.blade.php ENDPATH**/ ?>