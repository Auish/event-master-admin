
<!--
 * CoreUI - Open Source Bootstrap Admin Template
   * Copyright (c) 2016 creativeLabs Łukasz Holeczek
 * @  MIT
 -->
 <!DOCTYPE html>
 <html lang="IR-fa" dir="rtl">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="CoreUI Bootstrap 4 Admin Template" />
        <meta name="author" content="Lukasz Holeczek" />
        <meta name="keyword" content="CoreUI Bootstrap 4 Admin Template" />
        <title><?php echo $__env->yieldContent('name'); ?></title>
        <!-- Icons -->
        <link href="/backt/css/font-awesome.min.css" rel="stylesheet" />
        <link href="/backt/css/simple-line-icons.css" rel="stylesheet" />
        <!-- Main styles for this application -->
        <link href="/backt/dest/style.css" rel="stylesheet" />
        <?php echo $__env->yieldPushContent('stylesheest'); ?>
      </head>
   <!-- BODY options, add following classes to body to change options
          1. 'compact-nav'     	  - Switch sidebar to minified version (width 50px)
          2. 'sidebar-nav'		  - Navigation on the left
              2.1. 'sidebar-off-canvas'	- Off-Canvas
                  2.1.1 'sidebar-off-canvas-push'	- Off-Canvas which move content
                  2.1.2 'sidebar-off-canvas-with-shadow'	- Add shadow to body elements
          3. 'fixed-nav'			  - Fixed navigation
          4. 'navbar-fixed'		  - Fixed navbar
      -->
 
   <body class="navbar-fixed sidebar-nav fixed-nav">
     <header class="navbar">
       <div class="container-fluid">
         <button
           class="navbar-toggler mobile-toggler hidden-lg-up"
           type="button"
         >
           &#9776;
         </button>
         <a class="navbar-brand" href="#"></a>
         <ul class="nav navbar-nav hidden-md-down">
           <li class="nav-item">
             <a class="nav-link navbar-toggler layout-toggler" href="#"
               >&#9776;</a
             >
           </li>
 
           <!--<li class="nav-item p-x-1">
                      <a class="nav-link" href="#">داشبورد</a>
                 </li>
                 <li class="nav-item p-x-1">
                     <a class="nav-link" href="#">Users</a>
                 </li>
                 <li class="nav-item p-x-1">
                     <a class="nav-link" href="#">Settings</a>
                 </li>-->
         </ul>
         <ul class="nav navbar-nav pull-left hidden-md-down">
           <li class="nav-item">
             <a class="nav-link aside-toggle" href="#"
               ><i class="icon-bell"></i
               ><span class="tag tag-pill tag-danger">5</span></a
             >
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#"><i class="icon-list"></i></a>
           </li>
           <li class="nav-item">
             <a class="nav-link" href="#"><i class="icon-location-pin"></i></a>
           </li>
           <li class="nav-item dropdown">
             <a
               class="nav-link dropdown-toggle nav-link"
               data-toggle="dropdown"
               href="#"
               role="button"
               aria-haspopup="true"
               aria-expanded="false"
             >
               <img
                 src="<?php echo e(asset('backt/3.jpg')); ?>"
                 class="img-avatar"
                 alt="admin@bootstrapmaster.com"
               />
               <span class="hidden-md-down">مدیر</span>
             </a>
             <div class="dropdown-menu dropdown-menu-right">
               <div class="dropdown-header text-xs-center">
                 <strong>تنظیمات</strong>
               </div>
               <a class="dropdown-item" href="#"
                 ><i class="fa fa-user"></i> پروفایل</a
               >
               <a class="dropdown-item" href="#"
                 ><i class="fa fa-wrench"></i> تنظیمات</a
               >
               <!--<a class="dropdown-item" href="#"><i class="fa fa-usd"></i> Payments<span class="tag tag-default">42</span></a>-->
               <div class="divider"></div>
               <a class="dropdown-item" href="#"
                 ><i class="fa fa-lock"></i> خروج</a
               >
             </div>
           </li>
           <li class="nav-item">
             <a class="nav-link navbar-toggler aside-toggle" href="#">&#9776;</a>
           </li>
         </ul>
       </div>
     </header>
     <div class="sidebar">
        <nav class="sidebar-nav open">
            <ul class="nav">
              <li class="nav-item">
                <a class="nav-link" href="index.html"
                  ><i class="icon-speedometer"></i> Dashboard
                  <span class="tag tag-info">NEW</span></a
                >
              </li>
              <li class="nav-title">UI Elements</li>
              <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"
                  ><i class="icon-puzzle"></i> الادمن</a
                >
                <ul class="nav-dropdown-items">
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.create')); ?>">
                        <i class="icon-puzzle"></i> اضافه
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.list-admin')); ?>"
                      ><i class="icon-puzzle"></i> عرض</a
                    >
                  </li>
                </ul>
              </li>
              <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"
                  ><i class="icon-puzzle"></i> الخدمات</a
                >
                <ul class="nav-dropdown-items">
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.service.create')); ?>"
                      ><i class="icon-puzzle"></i> اضافه</a
                    >
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.service.list-service')); ?>"
                      ><i class="icon-puzzle"></i> عرض</a
                    >
                  </li>
                </ul>
              </li>
              <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"
                  ><i class="icon-puzzle"></i> خدمات فرعيه</a
                >
                <ul class="nav-dropdown-items">
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.Sub-service.create')); ?>"
                      ><i class="icon-puzzle"></i> اضافه</a
                    >
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.Sub-service.list-Sub-service')); ?>"
                      ><i class="icon-puzzle"></i> عرض</a
                    >
                  </li>
                </ul>
              </li>
              <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"
                  ><i class="icon-star"></i> المنتجات</a
                >
                <ul class="nav-dropdown-items">
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.products.create')); ?>">
                        <i class="icon-star"></i> اضافه
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.products.list-prodect')); ?>"
                      ><i class="icon-star"></i>عرض</a
                    >
                  </li>
                </ul>
              </li>
              <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"
                  ><i class="icon-star"></i> الاعلانات</a
                >
                <ul class="nav-dropdown-items">
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.Slider.create')); ?>"
                      ><i class="icon-star"></i> اضافه</a
                    >
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.Slider.list-Slider')); ?>"
                      ><i class="icon-star"></i>عرض</a
                    >
                  </li>
                </ul>
              </li>
              <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"
                  ><i class="icon-star"></i> النماذج</a
                >
                <ul class="nav-dropdown-items">
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.models.create')); ?>"
                      ><i class="icon-star"></i> اضافه</a
                    >
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.models.list-models')); ?>"
                      ><i class="icon-star"></i>عرض</a
                    >
                  </li>
                </ul>
              </li>
              <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"
                  ><i class="icon-star"></i> الطلبات</a
                >
                <ul class="nav-dropdown-items">
                  <li class="nav-item">
                    <a class="nav-link" href="#"><i class="icon-star"></i> اضافه</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#"><i class="icon-star"></i>عرض</a>
                  </li>
                </ul>
              </li>
              <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"
                  ><i class="icon-star"></i> الخصومات</a
                >
                <ul class="nav-dropdown-items">
                  <li class="nav-item">
                    <a class="nav-link" href="#"><i class="icon-star"></i> اضافه</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#"><i class="icon-star"></i>عرض</a>
                  </li>
                </ul>
              </li>
              <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"
                  ><i class="icon-star"></i> الفواتير</a
                >
                <ul class="nav-dropdown-items">
                  <li class="nav-item">
                    <a class="nav-link" href="#"><i class="icon-star"></i> اضافه</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="#"><i class="icon-star"></i>عرض</a>
                  </li>
                </ul>
              </li>
    
              <li class="divider"></li>
              <li class="nav-title">Extras</li>
              <li class="nav-item nav-dropdown">
                <a class="nav-link nav-dropdown-toggle" href="#"
                  ><i class="icon-star"></i> Pages</a
                >
                <ul class="nav-dropdown-items">
                  <li class="nav-item">
                    <a class="nav-link" href="pages-login.html" target="_top"
                      ><i class="icon-star"></i> Login</a
                    >
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="pages-register.html" target="_top"
                      ><i class="icon-star"></i> Register</a
                    >
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="pages-404.html" target="_top"
                      ><i class="icon-star"></i> Error 404</a
                    >
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="pages-500.html" target="_top"
                      ><i class="icon-star"></i> Error 500</a
                    >
                  </li>
                </ul>
              </li>
            </ul>
          </nav>
     </div>

     <!-- Main content -->
      
     
       <?php echo $__env->yieldPushContent('container'); ?>
      <!--/.container-fluid-->
     
      
 
     <footer class="footer">
       <span class="text-left">
         <a href="http://coreui.io">CoreUI</a> &copy; 2016 creativeLabs.
       </span>
       <span class="pull-right">
         Powered by <a href="http://coreui.io">CoreUI</a>
       </span>
     </footer>
 
     <script>
       function readURL(input) {
         if (input.files && input.files[0]) {
           var reader = new FileReader();
 
           reader.onload = function (e) {
             var imgElement = document.getElementById("div1");
             imgElement.src = e.target.result;
 
             var divId = input.getAttribute("set-to"); // تصحيح الخاصية set-to
             var divElement = document.getElementById(divId);
             divElement.innerHTML = ""; // تفريغ محتوى العنصر
             divElement.appendChild(imgElement);
           };
 
           reader.readAsDataURL(input.files[0]);
         }
       }
     </script>
 
     <!-- Bootstrap and necessary plugins -->
     <script src="/backt/js/libs/jquery.min.js"></script>
     <script src="/backt/js/libs/tether.min.js"></script>
     <script src="/backt/js/libs/bootstrap.min.js"></script>
     <script src="/backt/js/libs/pace.min.js"></script>
 
     <!-- Plugins and scripts required by all views -->
     <script src="/backt/js/libs/Chart.min.js"></script>
 
     <!-- CoreUI main scripts -->
 
     <script src="/backt/js/app.js"></script>
 
     <!-- Plugins and scripts required by this views -->
     <!-- Custom scripts required by this view -->
     <script src="/backt/js/views/main.js"></script>
 
     <!-- Grunt watch plugin -->
     <script src="//localhost:35729/livereload.js"></script>
     <?php echo $__env->yieldPushContent('scripts'); ?>
   </body>
 </html>
 <?php /**PATH D:\Desktop\data_base\resources\views/index.blade.php ENDPATH**/ ?>