

<?php $__env->startSection('name'); ?>
    <?php echo e(isset($name) ? $name : 'page name is here'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('container'); ?>
<main class="main">
    <ol class="breadcrumb">
      <li class="breadcrumb-item">الرئسيه</li>
      <li class="breadcrumb-item"><a href="#">الاعلانات</a></li>
         <li class="breadcrumb-item active">اضافه</li>
         <!-- Breadcrumb Menu-->
         <li class="breadcrumb-menu">
             <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                 <a class="btn btn-secondary" href="#"><i class="icon-speech"></i></a>
                 <a class="btn btn-secondary" href="./"><i class="icon-graph"></i> &nbsp;Dashboard</a>
          <a class="btn btn-secondary" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>
        </div>
      </li>
    </ol>
     
  <!--/row-->
  <div class="card">
     <div class="card-header">
       <strong>الادمن</strong>
     </div>
     <form class="form-horizontal" role="form" method="post" action="" enctype="multipart/form-data">
         <div class="form-group">
             <label for="SliderTitle" class="col-lg-2 col-sm-2 control-label"> اسم الاعلان </label>
             <div class="col-lg-7">
                 <input name="slider_title" type="text" class="form-control" placeholder="Slider Title" required="">
             </div>
         </div>
         <div class="form-group">
             <label for="SliderImage" class="control-label col-md-2 ">    اضاف صوره </label>
             <div class="controls col-md-9">
                 <div class="fileupload fileupload-new" data-provides="fileupload">
                     <span class="btn btn-default btn-file">
                         <input name="slider_file" type="file" class="default" onchange="readURL(this);" set-to="div3" required="">
                     </span>
                     <span class="fileupload-preview" style="margin-left:5px;"></span>
                     <a href="#" class="close fileupload-exists" data-dismiss="fileupload" style="float: none; margin-left:5px;"></a>
             </div>
 </div>
 </div>
 <div class="form-group last">
     <label for="SliderPreview" class="control-label col-md-2">    صور الاعلان </label>
     <div class="col-md-9">
        <div class="fileupload fileupload-new" data-provides="fileupload">
          <div class="fileupload-new thumbnail" style="width: 160px; height: 160px">
            <img style="height: 100%; width: 100%" src="http://www.placehold.it/200x160/EFEFEF/AAAAAA&amp;text=no+image" alt="" id="div7">
          </div>
        </div>
      </div>
 </div>
 <div class="form-group">
     <label for="SliderSequence" class="col-lg-2 col-sm-2 control-label"> نسبه الخصم  </label>
     <div class="col-lg-7">
         <input name="slider_sequence" type="number" class="form-control" placeholder="Slider Sequence" required="">
     </div>
 </div>
 <div class="form-group ">
     <label for="SliderStatus" class="control-label col-lg-2">حاله الاعلان </label>
     <div class="col-lg-7">
         <select name="slider_status" class="form-control m-bot15" required="">
                     <option> Active </option>
                     <option> Inactive </option>
                 </select>
     </div>
 </div>
 <div class="form-group">
     <div class="form-actions">
         <button type="submit" class="btn btn-primary">حفظ</button>
         <button type="button" class="btn btn-danger">الغاء</button>
     </div>

 </div>
 </form>
 </div>
 <!--/row-->

 <!--/row-->
 

 <!--/.container-fluid-->
 </main>
<?php $__env->stopPush(); ?>

 
    

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desktop\data_base\resources\views/admin/Slider/create.blade.php ENDPATH**/ ?>