 
    


<?php $__env->startSection('name'); ?>
    <?php echo e(isset($name) ? $name : 'page name is here'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('container'); ?>
<main class="main">
    <ol class="breadcrumb">
      <li class="breadcrumb-item">الرئسيه</li>
      <li class="breadcrumb-item"><a href="#">الاعلانات</a></li>
      <li class="breadcrumb-item active">عرض</li>
      <!-- Breadcrumb Menu-->
      <li class="breadcrumb-menu">
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
          <a class="btn btn-secondary" href="#"><i class="icon-speech"></i></a>
          <a class="btn btn-secondary" href="./"><i class="icon-graph"></i> &nbsp;Dashboard</a>
          <a class="btn btn-secondary" href="#"><i class="icon-settings"></i> &nbsp;Settings</a>
        </div>
      </li>
    </ol>
    <div class="row">
      <div class="col-lg-12">
        <div class="card">
          <div class="card-header">
            <i class="fa fa-align-justify"></i> عرض الادمن
          </div>
          <div class="card-block">
            <!-- Search and filter section -->
            <div class="row mb-2">
                <div class="col-md-6">
                    <input type="text" class="form-control" id="tableSearch" placeholder="Search...">
                </div>
                <div class="col-md-6">
                    <select class="form-control" id="roleFilter">
                        <option value="">Filter by Role</option>
                        <option value="Member">Member</option>
                        <option value="Staff">Staff</option>
                        <option value="Admin">Admin</option>
                    </select>
                </div>
            </div>
            <table class="table table-bordered table-striped table-condensed" id="dataTable">
                <thead>
                    <tr>
                        <th>الرقم</th>
                        <th>اسم الاعلان  </th>
                        <th>السعر</th>
                        <th>الوصف</th>
                        <th>صوره</th>
                        <th>الحاله</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>ملبوس الزفاف</td>
                        <td>10000</td>
                        <td>ملبوس الزفاف اناقه وراحه خلي عرسك يكتمل سعاده مع ملبوس التراث</td>
                        <td>
                          <img src="<?php echo e(asset('backt/preview_fashionable_long_sleeves_princess_ball_gown_wedding_dress_dress_font_b_shopping_b_font_sales_font.jpg')); ?>" class="img-avatar" alt="admin@bootstrapmaster.com" width="35px" height="35px">
                      </td>
                      
                        <td>
                            <span class="tag tag-success">نشط</span>
                        </td>
                        <td>
                          <button type="button" class="tag tag-success icon-note" style="margin-bottom: 4px">
                            <span>تعديل</span>
                          </button>
                          <button type="button" class="tag tag-danger icon-trash" style="margin-bottom: 4px">
                            <span>حذف</span>
                          </button>
                        </td>
           </tr>
        
           </tbody>
           </table>
           <div id="selectedRowData" class="mt-3"></div>
           <nav>
               <ul class="pagination">
                   <li class="page-item"><a class="page-link" href="#">Prev</a>
                   </li>
                   <li class="page-item active">
                       <a class="page-link" href="#">1</a>
                   </li>
                   <li class="page-item"><a class="page-link" href="#">2</a>
                   </li>
                   <li class="page-item"><a class="page-link" href="#">3</a>
                   </li>
                   <li class="page-item"><a class="page-link" href="#">4</a>
                   </li>
                   <li class="page-item"><a class="page-link" href="#">Next</a>
                   </li>
               </ul>
           </nav>
       </div>
        </div>
      </div>
      <!--/col-->
    </div>

    <!--/.container-fluid-->
  </main>
<?php $__env->stopPush(); ?>

 
    

<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Desktop\data_base\resources\views/admin/Slider/index.blade.php ENDPATH**/ ?>