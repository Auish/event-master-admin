<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('user_adrss', function (Blueprint $table) {
           // $table->id();
            $table->foreignId('user_id')->constrained('user');
            $table->foreignId('the_address_id')->constrained('the_address');
            $table->primary(['user_id','the_address_id']);
           // $table->primary(['user_id', 'the_address_id']);
            $table->timestamps();

        });
        /*
        if (!Schema::hasTable('user_adrss')) {
            Schema::create('user_adrss', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->bigInteger('user_id')->unsigned('user');
                $table->bigInteger('the_address_id')->unsigned('the_address');
                $table->timestamps();
            });*/
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('user_adrss');
    }
};
