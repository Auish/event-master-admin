<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('evaluation', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('user');
            $table->foreignId('services_id')->constrained('services');
            $table->foreignId('service_item_id')->constrained('service_item');
            $table->text('rating_vaiue');
            $table->text('comment');
            $table->timestamps();
        });
        /*
        Schema::create('evaluation', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('user_id')->unsigned('user');
            $table->bigInteger('services_id')->unsigned('services');
            $table->bigInteger('service_item_id')->unsigned('service_item');
            $table->text('rating_value');
            $table->text('comment');
            $table->timestamps();
        });*/
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('evaluation');
    }
};
