<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('prom_catgro', function (Blueprint $table) {
           // $table->id();
            $table->foreignId('category_id')->constrained('category');
            $table->foreignId('service_item_id')->constrained('service_item');
            $table->foreignId('services_id')->constrained('services');
            $table->foreignId('offers_id')->constrained('offers');
            $table->primary(['category_id','service_item_id']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('prom_catgro');
    }
};
