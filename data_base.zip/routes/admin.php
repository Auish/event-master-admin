<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;

// Route::prefix('admin')->name('admin.')->group(function() {

//     // مسارات الضيف (غير مسجل الدخول)
//     Route::middleware(['guest:admin'])->group(function() {
//         Route::view('/login', 'back.pages.admin.auth.login')->name('login');
//     });

//     // مسارات الأدمن المسجل (مسجل الدخول)
//     Route::middleware(['auth:admin'])->group(function() {
//         Route::view('/index', 'back.pages.admin.index')->name('index');
        
//         // مسارات إدارة الأدمن
//         Route::prefix('admins')->name('admins.')->group(function() {
//             Route::view('/create', 'back.pages.admin.admins.create')->name('create');
//             Route::view('/edit/{id}', 'back.pages.admin.admins.edit')->name('edit');
//             Route::view('/', 'back.pages.admin.admins.index')->name('list');
//         });

//         // مسارات إدارة المنتجات
//         Route::prefix('products')->name('products.')->group(function() {
//             Route::view('/create', 'back.pages.admin.products.create')->name('create');
//             Route::view('/edit/{id}', 'back.pages.admin.products.edit')->name('edit');
//             Route::view('/', 'back.pages.admin.products.index')->name('list');
//         });
//     });

// });


















Route::prefix('admin')->name('admin.')->group(function () {

    Route::middleware(['guest:admin'])->group(function () {
        Route::view('/login', 'admin.home')->name('login');
        Route::view('/create', 'admin.admins.create')->name('create');
        Route::view('/list-admin', 'admin.admins.index')->name('list-admin');
    });
         // مسارات إدارة المنتجات
        Route::prefix('products')->name('products.')->group(function() {
            Route::view('/create', 'admin.products.create')->name('create');
            Route::view('/edit/{id}', 'admin.products.create')->name('edit');
            Route::view('list-prodect', 'admin.products.index')->name('list-prodect');
        });
         // مسارات إدارة الخدمات
        Route::prefix('service')->name('service.')->group(function() {
            Route::view('/create', 'admin.service.create')->name('create');
            Route::view('/edit/{id}', 'admin.service.create')->name('edit');
            Route::view('list-service', 'admin.service.index')->name('list-service');
        });
         //  مسارات إدارة الخدمات الفرعيه
        Route::prefix('Sub-service')->name('Sub-service.')->group(function() {
            Route::view('/create', 'admin.Sub-service.create')->name('create');
            Route::view('/edit/{id}', 'admin.Sub-service.create')->name('edit');
            Route::view('list-Sub-service', 'admin.Sub-service.index')->name('list-Sub-service');
        });
         //  مسارات إدارة   الاعلانات
        Route::prefix('Slider')->name('Slider.')->group(function() {
            Route::view('/create', 'admin.Slider.create')->name('create');
            Route::view('/edit/{id}', 'admin.Slider.create')->name('edit');
            Route::view('list-Slider', 'admin.Slider.index')->name('list-Slider');
        });
         //  مسارات إدارة   النماذج
        Route::prefix('models')->name('models.')->group(function() {
            Route::view('/create', 'admin.models.create')->name('create');
            Route::view('/create-data', 'admin.models.craet-db')->name('create-data');
            Route::view('/edit/{id}', 'admin.models.create')->name('edit');
            Route::view('list-models', 'admin.models.index')->name('list-models');
            Route::view('list-models-mor', 'admin.models.list-model')->name('list-models-mor');
        });
    Route::middleware(['auth:admin'])->group(function(){
        Route::view('/index','back.pages.admin.index')->name('index');
});

});